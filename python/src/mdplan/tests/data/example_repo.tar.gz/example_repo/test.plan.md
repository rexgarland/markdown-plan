# Test plan

1. [x] write a test
2. [x] watch it fail
3. [x] make it pass
   - write messy logic
   - hard-code some values
4. [x] refactor
